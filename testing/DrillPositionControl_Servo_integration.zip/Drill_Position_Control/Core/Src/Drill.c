 /*
 * Drill.c
 *
 *  Created on: Dec 10, 2025
 *      Author: Khaled ElSisy
 */

#include "main.h"
#include "Drill.h"

int32_t encoder_current = 0;

double angularPosition = 0;
double distance = 0;
double error = 0;
double setpoint = 0;

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim5;
extern TIM_HandleTypeDef htim11;

extern UART_HandleTypeDef huart2;

/**
  * @brief  Sets the duty cycle of PWM signal controlling the drill motor.
  * @param  value: the desired PWM duty cycle value. (-255 <= value <= 255)
  * @retval None
  */
void setDutyCycle(int32_t value)
{
	// Clipping to physical limits
  if (value > 1023) value = 1023;
  if (value < -1023) value = -1023;

  if (value < 0)
  {
	  __HAL_TIM_SET_COMPARE(PWM_TIM_H, PWM_TIM_CHANNEL, -1*value);
	  HAL_GPIO_WritePin(MotorDir_PORT, MotorDir_PIN, 0);
  }
  else
  {
	  __HAL_TIM_SET_COMPARE(PWM_TIM_H, PWM_TIM_CHANNEL, value);
	  HAL_GPIO_WritePin(MotorDir_PORT, MotorDir_PIN, 1);
  }
}

/**
  * @brief  Calculates required control output. It should be called periodically with a fixed time step.
  * @retval None
  */

void ProportionalControl()
{
	int32_t dutycycle = 0;

	encoder_current = __HAL_TIM_GetCounter(ENCODER_TIM_H);

	// Position (cm)
	angularPosition = encoder_current / PULSES_PER_DEGREE;
	distance = angularPosition / DEGREES_PER_CM;

	error = (setpoint - angularPosition);

	// Proportional Control Equation: ControlOutput = kp * error
	dutycycle = kp * error;

	setDutyCycle((int32_t)dutycycle);
}

/**
  * @brief  Sets the new position target for the drill motor.
  * @param  newPosition: the new desired position of the drill motor.
  * @retval None
  */
void setPosition(double newPosition)
{
	setpoint = newPosition;
}

void sendCurrentValues()
{
	char str[20] = "                    ";
	HAL_UART_Transmit(&huart2, "Distance:   ", 10, HAL_MAX_DELAY);
	sprintf(str, "%d mm    \n", (int)(10*distance));
	HAL_UART_Transmit(&huart2, str, sizeof(str), HAL_MAX_DELAY);
	char str1[20] = "                    ";
	HAL_UART_Transmit(&huart2, "Set Point:   ", 10, HAL_MAX_DELAY);
	sprintf(str1, "%d.%d     \n", (int)setpoint, (int)abs(100 * setpoint - ((int)setpoint) * 100));
	HAL_UART_Transmit(&huart2, str1, sizeof(str1), HAL_MAX_DELAY);
	char str2[20] = "                    ";
	HAL_UART_Transmit(&huart2, "Duty Cycle:   ", 14, HAL_MAX_DELAY);
	sprintf(str2, "%d     \n", (int)__HAL_TIM_GetCompare(PWM_TIM_H, PWM_TIM_CHANNEL));
	HAL_UART_Transmit(&huart2, str2, sizeof(str2), HAL_MAX_DELAY);
	char str3[20] = "                    ";
	HAL_UART_Transmit(&huart2, "Error:    ", 10, HAL_MAX_DELAY);
	sprintf(str3, "%d     \n", (int)error);
	HAL_UART_Transmit(&huart2, str3, sizeof(str3), HAL_MAX_DELAY);
	char str4[20] = "                    ";
	HAL_UART_Transmit(&huart2, "Encoder:  ", 10, HAL_MAX_DELAY);
	sprintf(str4, "%d     \n", encoder_current);
	HAL_UART_Transmit(&huart2, str4, sizeof(str4), HAL_MAX_DELAY);

//	char str[] = "                                                                                             ";
//	sprintf(str,
//			" Position: %d cm  Setpoint: %d cm  DutyCycle: %d  Error: %d cm  Encoder: %d \n",
//			(int)position,
//			(int)setpoint,
//			(int)__HAL_TIM_GetCompare(PWM_TIM_H, PWM_TIM_CHANNEL),
//			(int)error,
//			(int)encoder_current
//			);
//	HAL_UART_Transmit_IT(&huart2, str, sizeof(str));
	/*
	 * Format:
	 * | Position: 50.0cm | Setpoint: 50.0cm | DutyCycle: 255 | Error: 50.0cm | Encoder: 500000 |
	 */
}
