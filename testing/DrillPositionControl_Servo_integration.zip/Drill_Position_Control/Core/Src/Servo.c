/*
 * Servo.c
 *
 *  Created on: Feb 2, 2026
 *      Author: Jessica Jacob
 */

#include "Servo.h"


void Servo_setAngle(TIM_HandleTypeDef *htim, uint32_t channel, uint16_t angle)
{
	// Clamp to 0–180
		if (angle > MAX_ANGLE)
			angle = MAX_ANGLE;


		uint32_t RANGE = MAX_PULSE - MIN_PULSE;

		// Map 0–360° → 1–2 ms range
		// Convert to timer counts
		uint32_t Pulse = MIN_PULSE + (angle * RANGE) / MAX_ANGLE;

		__HAL_TIM_SET_COMPARE(htim, channel, Pulse);
}
