 /*
 * Servo.h
 *
 *  Created on: Feb 2, 2026
 *      Author: Jessica Jacob
 */

#ifndef SERVO_H_
#define SERVO_H_

#include "stm32f4xx_hal.h"

#define		MIN_PULSE 540  // 1 ms → 1000 ticks
#define 	MAX_PULSE 2400  // 2 ms → 2000 ticks
#define 	MAX_ANGLE 180


void Servo_setAngle(TIM_HandleTypeDef *htim, uint32_t channel, uint16_t angle);
#endif /* SERVO_H_ */
