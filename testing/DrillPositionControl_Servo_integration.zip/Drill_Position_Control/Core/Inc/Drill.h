/*
 * Drill.h
 *
 *  Created on: Dec 10, 2025
 *      Author: Khaled ElSisy
 */

#ifndef INC_DRILL_H_
#define INC_DRILL_H_


#define PWM_TIM_H &htim11
#define PWM_TIM_CHANNEL TIM_CHANNEL_1

#define ENCODER_TIM_H &htim2

#define MotorDir_PORT MotorDirection_GPIO_Port
#define MotorDir_PIN MotorDirection_Pin

#define PULSES_PER_DEGREE (2645.0/360)
#define DEGREES_PER_CM 450
#define kp (68.0)

#define _GET_TENTHS(__VALUE__) abs(floor(10 * (__VALUE__ - floor(__VALUE__))))
#define _PARSE_POSITION_REQUEST(_X_) ((!(_X_[0] == '-')) * 2 - 1)*((_X_[1] - 48) * 100 + (_X_[2] - 48) * 10 + (_X_[3] - 48))

void setDutyCycle(int32_t value);
void ProportionalControl();
void sendCurrentValues();
void setPosition(double newPosition);

#endif /* INC_DRILL_H_ */
